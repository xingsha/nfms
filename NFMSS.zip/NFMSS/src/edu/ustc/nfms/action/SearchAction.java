package edu.ustc.nfms.action;

import java.util.List;
import com.opensymphony.xwork2.ActionContext;
import edu.ustc.nfms.entity.User;
import edu.ustc.nfms.service.FileService;

public class SearchAction {

	private FileService fileService;
	
	public void setFileService(FileService fileService) {
		this.fileService = fileService;
	}

	private String searchvalue;
	
	public String getSearchvalue() {
		return searchvalue;
	}

	public void setSearchvalue(String searchvalue) {
		this.searchvalue = searchvalue;
	}

	public String searchfile() {
		
		List<User> files = this.fileService.searchfile(searchvalue);
		ActionContext.getContext().put("files", files);
		return "files";
	} 
}
