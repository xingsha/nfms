package edu.ustc.nfms.action;

import java.io.FileInputStream;
import java.io.InputStream;
import java.net.URLEncoder;

import org.apache.commons.io.FilenameUtils;
import org.apache.struts2.ServletActionContext;
import org.springframework.beans.BeanUtils;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.ModelDriven;

import edu.ustc.nfms.entity.FileBean;
import edu.ustc.nfms.service.FileService;

@SuppressWarnings("serial")
public class FileDownloadAction extends ActionSupport implements ModelDriven<FileBean> {
	
	FileBean fileBean = new FileBean();
	
	@Override
	public FileBean getModel() {
		
		return fileBean;
	}

	public FileService getFileService() {
		return fileService;
	}

	//spring 注入
	private FileService fileService;
	
	public void setFileService(FileService fileService) {
		this.fileService = fileService;
	}
	
	private InputStream inputStream;//定义一个输入流。名字不能为in
	
	private String fileName;
	
	public InputStream getInputStream() {
		return inputStream;
	}

	public void setInputStream(InputStream inputStream) {
		this.inputStream = inputStream;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public String download() throws Exception{
		FileBean file = new FileBean();
		BeanUtils.copyProperties(this.getModel(), file);
		ApplicationContext ac = new ClassPathXmlApplicationContext("beans.xml");//新加1
		fileService = (FileService)ac.getBean("FileService");
		FileBean downloadfile = this.fileService.getFileById(file.getFileId());
		fileName = downloadfile.getFilesFileName();
		
		String realPath = downloadfile.getFilePath();
		System.out.println(realPath);
		String fullpath=realPath+"/"+fileName;
		inputStream = new FileInputStream(fullpath);
		//System.out.println(realPath+"test-test-test"+fileName);
	
		/*//实现下载：给inputStream赋值
		String realPath = ServletActionContext.getServletContext().getRealPath("meinv");
		fileName = URLEncoder.encode(FilenameUtils.getName(realPath),"UTF-8");
		inputStream = new FileInputStream(realPath);*/
		
		return SUCCESS;
	}
}
