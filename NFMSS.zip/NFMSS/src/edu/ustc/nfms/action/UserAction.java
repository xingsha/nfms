package edu.ustc.nfms.action;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletContext;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts2.ServletActionContext;
import org.springframework.beans.BeanUtils;

import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.ModelDriven;

import edu.ustc.nfms.entity.User;
import edu.ustc.nfms.service.UserService;

@SuppressWarnings("serial")
public class UserAction extends ActionSupport implements ModelDriven<User>{
	//模型驱动
	private User user = new User();
	
	
	public User getModel() {
		
		return user;
	}
	//注册
	public String regist(){
		userService.save(user);
		
		return "regist";
	}
	//注入UserService
	private UserService userService;
	public void setUserService(UserService userService) {
		this.userService = userService;
	}

	//Ajax 异步验证用户名
	public String findByUsername() throws IOException{
		//
		User existUser = userService.findByUsername(user.getUsername());
		//
		HttpServletResponse response = ServletActionContext.getResponse();
		response.setContentType("text/html;charset=utf-8");
		if(existUser != null){
			//
			response.getWriter().println("<font color='red'>用户名已经存在</font>");
		}else{
			//
			response.getWriter().println("<font color='green'>可以注册</font>");
		}
		return NONE;
	}
	//登录
	public String Login(){
		if(user.getUsername().equals("admin")&&user.getPassword().equals("admin")){
			return "admin";
		}
		User existUser = userService.login(user);
		
		if(existUser == null){
			//登录失败
			this.addActionError("用户名或密码错误");
			return "login";
		}else{
			//成功登陆
			//username存入session
			String username = existUser.getUsername();
			ServletActionContext.getRequest().getSession().setAttribute("username", username);
			
			return "success";
		}
		
	}
	public String logout(){
		
		//ServletActionContext.getRequest().getSession().invalidate();
		return "logout";
	}
	//我的文件
	public String getMyFiles(){
		int userid=user.getUserid();
		FileAction fa = new FileAction();
		fa.getMyFiles(userid);
		return "files";
	}
	
	//查找全部用户
	public String ggetAllUsers() {
		List<User> users = this.userService.getAllUser();
		ActionContext.getContext().put("users", users);
		return "users";
	}
	//删除用户
		public String deleteUserById(){
			User deleteuser = new User();
			BeanUtils.copyProperties(this.getModel(), deleteuser);	
			this.userService.deleteUser(deleteuser);
			return "deletefinish";
		}
		
		//�����û���Ϣ
		public String updateUser(){
			User updateuser = new User();	
			BeanUtils.copyProperties(this.getModel(), updateuser);		
			String username = (String)ServletActionContext.getRequest().getSession().getAttribute("username");
			User olduser = this.userService.findByUsername(username);	
			olduser.setUsername(updateuser.getUsername());
			olduser.setEmail(updateuser.getEmail());
			this.userService.updateUser(olduser);
			return "updatefinish";
		}
	
}
