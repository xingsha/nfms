package edu.ustc.nfms.action;

import java.io.File;
import java.io.IOException;

import javax.servlet.ServletContext;

import org.apache.commons.io.FileUtils;
import org.apache.struts2.ServletActionContext;
import org.hibernate.Session;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;

import edu.ustc.nfms.entity.FileBean;
import edu.ustc.nfms.entity.User;
import edu.ustc.nfms.service.UserService;

@SuppressWarnings("serial")
public class FileUploadAction extends ActionSupport{
	
	UserService us;
	
	public UserService getUs() {
		return us;
	}

	public void setUs(UserService us) {
		this.us = us;
	}
	FileAction fa ;
	
	public FileAction getFa() {
		return fa;
	}

	public void setFa(FileAction fa) {
		this.fa = fa;
	}
	private File upload;
	private String uploadFileName;
	private String uploadContentType;
	private ServletContext sc;
	
	public String execute(){
		//获取文件地址
		 sc = ServletActionContext.getServletContext();
		String directory = sc.getRealPath("/files");//
		//目标文件
		
		File target = new File(directory, uploadFileName);	
		
		
			try {
				FileUtils.copyFile(upload, target);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
		FileBean fib = new FileBean();
		fib.setFilesFileName(uploadFileName);
		fib.setFilesContentType(uploadContentType);
		fib.setFilePath(directory);
		//fib.setFileId(4);
		
		String username = (String)ServletActionContext.getRequest().getSession().getAttribute("username");
		ApplicationContext ac1 = new ClassPathXmlApplicationContext("beans.xml");//新加1
	    UserService us = (UserService)ac1.getBean("UserService");
		User u=us.findByUsername(username);
		
		fib.setFileOwner(u.getUserid());
		fib.setFileSize("333");
		fib.setIsOpen(0);
		fib.setUploadTime("2016-02-25");
		System.out.println(fib.getFilesFileName()+"=================");
		
		ApplicationContext ac = new ClassPathXmlApplicationContext("beans.xml");//新加1
	    fa = (FileAction)ac.getBean("FileAction");
		
		fa.uploadfile(fib);
		return SUCCESS;
		
		}



	public File getUpload() {
		return upload;
	}
	public void setUpload(File upload) {
		this.upload = upload;
	}
	public String getUploadFileName() {
		return uploadFileName;
	}
	public void setUploadFileName(String uploadFileName) {
		this.uploadFileName = uploadFileName;
	}
	public String getUploadContentType() {
		return uploadContentType;
	}
	public void setUploadContentType(String uploadContentType) {
		this.uploadContentType = uploadContentType;
	}
	public ServletContext getSc() {
		return sc;
	}
	public void setSc(ServletContext sc) {
		this.sc = sc;
	}

}
