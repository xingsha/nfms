package edu.ustc.nfms.action;

import java.io.File;
import java.io.IOException;
import java.util.Date;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.FileUtils;
import org.apache.log4j.spi.ThrowableRenderer;
import org.apache.struts2.ServletActionContext;
import org.hibernate.ejb.criteria.expression.function.CurrentTimeFunction;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Required;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.http.HttpRequest;

 
import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.ModelDriven;

import edu.ustc.nfms.entity.FileBean;
import edu.ustc.nfms.entity.User;
import edu.ustc.nfms.service.FileService;
import edu.ustc.nfms.service.UserService;


@SuppressWarnings("serial")

public class FileAction extends ActionSupport  implements ModelDriven<FileBean>{
	
	FileBean fileBean = new FileBean();
	@Override
	public FileBean getModel() {
		
		return fileBean;
	}

	public FileService getFileService() {
		return fileService;
	}

	//spring 注入
	private FileService fileService;
	
	public void setFileService(FileService fileService) {
		this.fileService = fileService;
	}

	private UserService userService;
	public void setUserService(UserService userService) {
		this.userService = userService;
	}

	public void uploadfile(FileBean fib){
		
		
		fileService.save(fib);

		}

	public String ggetAllFiles() {
		List<User> files = this.fileService.getAllFiles();
		ActionContext.getContext().put("files", files);
		return "files";
	}
	public String getMusics() {
		List<User> files = this.fileService.getMusics();
		ActionContext.getContext().put("files", files);
		return "files";
	}
	public String getVideo() {
		List<User> files = this.fileService.getVideo();
		ActionContext.getContext().put("files", files);
		return "files";
	}
	public String getPictures() {
		List<User> files = this.fileService.getPictures();
		ActionContext.getContext().put("files", files);
		return "files";
	}
	
	public String getMyFiles(int userid) {
		
		ApplicationContext ac = new ClassPathXmlApplicationContext("beans.xml");//新加1
	    FileService fs = (FileService)ac.getBean("FileService");
		fs.getMyFiles(userid);
		return "files";
	
}
	
	public String getCommonFiles(){
		List<User> files = this.fileService.getCommonFiles();
		ActionContext.getContext().put("files", files);
		return "files";	
	}
	
	public String OpenFiles(){
		
		fileService.OpenFiles(fileBean.getFileId());
		return "files";
		
	}
	
	public String deleteFileById(){
		FileBean deletefile = new FileBean();
		BeanUtils.copyProperties(this.getModel(), deletefile);	
		this.fileService.delete(deletefile);
		return "deletefinish";
	}
	private String searchvalue;
	
	public String getSearchvalue() {
		return searchvalue;
	}

	public void setSearchvalue(String searchvalue) {
		this.searchvalue = searchvalue;
	}

	public String searchfile() {
		
		List<User> files = this.fileService.searchfile(searchvalue);
		ActionContext.getContext().put("files", files);
		return "files";
	} 
	public String previewFile(){
		FileBean file = new FileBean();
		BeanUtils.copyProperties(this.getModel(), file);
		FileBean previewfile = this.fileService.getFileById(file.getFileId());
		String type = previewfile.getFilesContentType();
	    String name = previewfile.getFilesFileName();
	    ActionContext.getContext().put("filename",name);
	    if (type.indexOf("video") >= 0)
	    {
	    	return "video";
	    }
	    if (type.indexOf("image") >= 0)
	    {
	    	return "image";
	    }
	    if (type.indexOf("audio") >= 0)
	    {
	    	return "audio";
	    }
		return "error";
	}
}


