package edu.ustc.nfms.entity;

public class User {

	private int userid;
	private String username;
	private String password;
	private int IsAdmin;
	private String email;
	
	private int totalStorage;
	private int available;
	private int ver;
	
	public int getVer() {
		return ver;
	}
	public void setVer(int ver) {
		this.ver = ver;
	}
	public int getUserid() {
		return userid;
	}
	public void setUserid(int userid) {
		this.userid = userid;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public int getIsAdmin() {
		return IsAdmin;
	}
	public void setIsAdmin(int isAdmin) {
		IsAdmin = isAdmin;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public int getTotalStorage() {
		return totalStorage;
	}
	public void setTotalStorage(int totalStorage) {
		this.totalStorage = totalStorage;
	}
	public int getAvailable() {
		return available;
	}
	public void setAvailable(int available) {
		this.available = available;
	}
	


}
