package edu.ustc.nfms.entity;

import java.io.File;
import java.io.Serializable;


public class FileBean {
	
	private int fileId;
	private String filesFileName;
	private String filesContentType;
	private String filePath;
	private String fileSize;
	private String uploadTime;
	private int IsOpen;
	private int fileOwner;
	//private File files;
	public int getFileId() {
		return fileId;
	}
	public void setFileId(int fileId) {
		this.fileId = fileId;
	}
	public String getFilesFileName() {
		return filesFileName;
	}
	public void setFilesFileName(String filesFileName) {
		this.filesFileName = filesFileName;
	}
	public String getFilesContentType() {
		return filesContentType;
	}
	public void setFilesContentType(String filesContentType) {
		this.filesContentType = filesContentType;
	}
	public String getFilePath() {
		return filePath;
	}
	public void setFilePath(String filePath) {
		this.filePath = filePath;
	}
	public String getFileSize() {
		return fileSize;
	}
	public void setFileSize(String l) {
		this.fileSize = l;
	}
	public String getUploadTime() {
		return uploadTime;
	}
	public void setUploadTime(String dt) {
		this.uploadTime = dt;
	}
	public int getIsOpen() {
		return IsOpen;
	}
	public void setIsOpen(int isOpen) {
		IsOpen = isOpen;
	}
	public int getFileOwner() {
		return fileOwner;
	}
	public void setFileOwner(int fileOwner) {
		this.fileOwner = fileOwner;
	}
	/*public File getFiles() {
		return files;
	}
	public void setFiles(File files) {
		this.files = files;
	}*/
	/*@Override
	public String toString() {
		return "FileBean [fileId=" + fileId + ", filesFileName="
				+ filesFileName + ", filesContentType=" + filesContentType
				+ ", filePath=" + filePath + ", fileSize=" + fileSize
				+ ", uploadTime=" + uploadTime + ", IsOpen=" + IsOpen
				+ ", fileOwner=" + fileOwner + ", files=" + files + "]";
	}*/
	
	
}
