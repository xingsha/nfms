package edu.ustc.nfms.dao;

import java.util.List;

import javax.annotation.Resource;

import org.hibernate.SessionFactory;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
import edu.ustc.nfms.entity.FileBean;
import edu.ustc.nfms.entity.User;

public class FileDao extends HibernateDaoSupport{
	@Resource
	public void setSessionFactory0(SessionFactory sessionFactory){  
	super.setSessionFactory(sessionFactory);  
	}
	
	public void save(FileBean fib) {
		
		super.getHibernateTemplate().save(fib);
		//this.getHibernateTemplate().save(fib);
		//ht.save(fib);
	}

	public List<User> getAllFiles() {
		
		return  this.getHibernateTemplate().find("from FileBean");
	}
	public List<User> getMusics() {
			
			return  this.getHibernateTemplate().find("from FileBean where FileType like 'audio%'");
		}
	public List<User> getVideo() {
		
		return  this.getHibernateTemplate().find("from FileBean where FileType like 'video%'");
	}
	public List<User> getPictures() {
		
		return  this.getHibernateTemplate().find("from FileBean where FileType like 'image%'");
	}
		
	public List<User> getMyFiles(int userid) {
			String hql ="from FileBean where fileOwner = ?";
			return  this.getHibernateTemplate().find(hql,userid);
		}
		
	
	public void delete(FileBean fileBean){
		this.getHibernateTemplate().delete(fileBean);
		
	}
	public FileBean getFileById(int id) {
		
		String hql = "from FileBean where fileid = ?";
		List<FileBean> list = this.getHibernateTemplate().find(hql, id);
		if(list != null&&list.size()>0){
			return list.get(0);
		}
		return null;
	}

		public List<User> getCommonFiles() {
			
			return  this.getHibernateTemplate().find("from FileBean where IsOpen='1'");
		}
		public List<User> searchfile(String text) {
			
			String hql="from FileBean where name like '%"+text+"%'";
			return  this.getHibernateTemplate().find(hql);
		}
}
