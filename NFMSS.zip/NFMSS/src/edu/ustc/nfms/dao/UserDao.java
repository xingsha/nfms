package edu.ustc.nfms.dao;

import java.util.List;

import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import edu.ustc.nfms.entity.FileBean;
import edu.ustc.nfms.entity.User;

public class UserDao extends HibernateDaoSupport{
	//按姓名查找用户

	public User findByUsername(String username){
		String hql = "from User where username = ?";
		List<User> list = this.getHibernateTemplate().find(hql, username);
		if(list != null&&list.size()>0){
			return list.get(0);
		}
		return null;
	}
	//用户信息写入数据库
	public void save(User user) {
		
		
		this.getHibernateTemplate().save(user);
		
	}
	//文件信息写入数据库
		public void savefile(FileBean fib) {
			this.getHibernateTemplate().save(fib);
		}
	
	
	
	
	public User login(User user) {
		// TODO Auto-generated method stub
		String hql = "from User where username=? and password=? and IsAdmin=?";
		List<User> list = this.getHibernateTemplate().find(hql, user.getUsername(), user.getPassword(), user.getIsAdmin());
		if(list != null && list.size() > 0){
			return list.get(0);
		}
		return null;
	}
	
	//��ѯ�����û�
	public List<User> getAllUser() {
		
		return this.getHibernateTemplate().find("from User");
	}
	
	
	//ɾ���û�
		public void deleteUser(User user) {
			
			this.getHibernateTemplate().delete(user);
			
		}
		//�����û�
		public void updateUser(User user){
			this.getHibernateTemplate().update(user);
		}

}
