package edu.ustc.nfms.service;

import java.util.List;

import org.springframework.transaction.annotation.Transactional;

import edu.ustc.nfms.dao.FileDao;
import edu.ustc.nfms.dao.UserDao;
import edu.ustc.nfms.entity.FileBean;
import edu.ustc.nfms.entity.User;

@Transactional
public class UserService {
	//注入Dao
	private UserDao userDao = new UserDao();

	public void setUserDao(UserDao userDao) {
		this.userDao = userDao;
	}
	
	
	//按姓名查找
	public User findByUsername(String username){
		return userDao.findByUsername(username);
	}
	//用户信息写入数据库
	public void save(User user) {
		
		user.setIsAdmin(0);  //0����ͨ�û�    1������Ա
		user.setTotalStorage(10);  
		user.setAvailable(10);
		userDao.save(user);
		
	}
	
	
	
	
	//文件信息写入数据库
		public void savefile(FileBean fib) {
			
			userDao.savefile(fib);
			
		}
	
	
	
	//用户注册
	public User login(User user) {
		
		return userDao.login(user);
	}
	//查看用户
	public List<User> getAllUser() {
		
		return userDao.getAllUser();
	}
	public void deleteUser(User deleteuser) {
	
		userDao.deleteUser(deleteuser);
		
	}
	public void updateUser(User olduser) {
		
		userDao.updateUser(olduser);
		
	}
	

}
