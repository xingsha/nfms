package edu.ustc.nfms.service;


import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.transaction.annotation.Transactional;

import edu.ustc.nfms.dao.FileDao;
import edu.ustc.nfms.entity.FileBean;
import edu.ustc.nfms.entity.User;


@Transactional
public class FileService {
	
	//注入Dao
		private FileDao fileDao;;

		

		public FileDao getFileDao() {
			return fileDao;
		}
		
		public void setFileDao(FileDao fileDao) {
			this.fileDao = fileDao;
		}



	public void save(FileBean fib) {
		
		
		
		System.out.println("getFilesFileName:"+fib.getFilesFileName());
		
		System.out.println("fs.fileDao:"+fileDao);
		fileDao.save(fib);
		
		//fileDao.save(fib);
		
	}
		public List<User> getAllFiles() {
		
			return fileDao.getAllFiles();
		
	}
		public List<User> getMusics() {
			
			return fileDao.getMusics();
		
	}
		public List<User> getVideo() {
			
			return fileDao.getVideo();
		
	}
		public List<User> getPictures() {
			
			return fileDao.getPictures();
		
	}
		public List<User> getMyFiles(int userid) {
			
			return fileDao.getMyFiles(userid);
		
	}
		public List<User> getCommonFiles() {
			
			return fileDao.getCommonFiles();
		
	}
		public void OpenFiles(int id){
			
			FileBean fb =fileDao.getFileById(id);
			fb.setIsOpen(1);
			fileDao.save(fb);
		}
		
		public void delete(FileBean fileBean) {
			
			fileDao.delete(fileBean);
		}
		public FileBean getFileById(int id)
		{
			return fileDao.getFileById(id);
		}
		public List<User> searchfile(String text) {
			
			return fileDao.searchfile(text);
		
	}
}
